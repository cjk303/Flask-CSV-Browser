
import os
import subprocess
import tempfile
from flask import Flask, render_template, request, redirect, url_for, flash
from flask_login import LoginManager, login_user, logout_user, login_required, UserMixin, current_user
from utils import tacacs
from auth import authenticate

app = Flask(__name__)
app.secret_key = 'your-super-secret-key'

# Paths
TACACS_CONFIG_PATH = '/etc/tacacs/tac_plus.conf'
BACKUP_DIR = './backups'
os.makedirs(BACKUP_DIR, exist_ok=True)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

class User(UserMixin):
    def __init__(self, id):
        self.id = id

@login_manager.user_loader
def load_user(user_id):
    return User(user_id)

def backup_config():
    import datetime
    if os.path.exists(TACACS_CONFIG_PATH):
        timestamp = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
        backup_file = os.path.join(BACKUP_DIR, f'tac_plus.conf.bak.{timestamp}')
        with open(TACACS_CONFIG_PATH, 'r') as src, open(backup_file, 'w') as dst:
            dst.write(src.read())

def validate_config(config_path):
    # Placeholder: implement actual validation or external tool call
    # For demo, just check if file is readable and not empty
    try:
        with open(config_path) as f:
            content = f.read()
            if content.strip() == "":
                return False, "Config file is empty."
            else:
                return True, ""
    except Exception as e:
        return False, str(e)

@app.route('/')
@login_required
def index():
    # Validate config
    config_valid = False
    output = ""
    if os.path.exists(TACACS_CONFIG_PATH):
        with tempfile.NamedTemporaryFile('w', delete=False) as tmp:
            tmp.write(open(TACACS_CONFIG_PATH).read())
            tmp_path = tmp.name
        config_valid, output = validate_config(tmp_path)
        os.unlink(tmp_path)

    # Check docker container running status
    try:
        result = subprocess.run(['docker', 'inspect', '-f', '{{.State.Running}}', 'tac_plus'],
                                capture_output=True, text=True)
        running_str = result.stdout.strip()
        service_status = 'active' if running_str == 'true' else 'inactive'
    except Exception:
        service_status = "unknown"

    num_backups = len(os.listdir(BACKUP_DIR)) if os.path.exists(BACKUP_DIR) else 0

    return render_template('index.html',
                           config_valid=config_valid,
                           service_status=service_status,
                           backup_count=num_backups,
                           validation_output=output)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if authenticate(username, password):
            user = User(username)
            login_user(user)
            flash(f"Welcome, {username}", "success")
            return redirect(url_for('index'))
        else:
            flash("Invalid LDAP credentials", "error")

    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash("Logged out successfully.", "info")
    return redirect(url_for('login'))

@app.route('/edit-tacacs', methods=['GET', 'POST'])
@login_required
def edit_tacacs():
    if request.method == 'POST':
        new_content = request.form['config']
        try:
            backup_config()
            with open(TACACS_CONFIG_PATH, 'w') as f:
                f.write(new_content)

            # Restart Docker container instead of systemctl
            subprocess.run(['docker', 'restart', 'tac_plus'])

            flash("Configuration saved and container restarted.", "success")
        except Exception as e:
            flash(f"Error saving config: {e}", "error")
        return redirect(url_for('edit_tacacs'))

    config_content = ""
    if os.path.exists(TACACS_CONFIG_PATH):
        with open(TACACS_CONFIG_PATH) as f:
            config_content = f.read()

    return render_template('edit_tacacs.html', config=config_content)

@app.route('/backups')
@login_required
def view_backups():
    backups = []
    if os.path.exists(BACKUP_DIR):
        backups = sorted(os.listdir(BACKUP_DIR), reverse=True)
    return render_template('backups.html', backups=backups)

@app.route('/backups/<backup_name>')
@login_required
def view_backup_file(backup_name):
    backup_path = os.path.join(BACKUP_DIR, backup_name)
    if os.path.exists(backup_path):
        with open(backup_path) as f:
            content = f.read()
        return render_template('backup_view.html', backup_name=backup_name, content=content)
    else:
        flash("Backup not found.", "error")
        return redirect(url_for('view_backups'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
