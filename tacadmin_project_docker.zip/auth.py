
from ldap3 import Server, Connection, ALL, NTLM

LDAP_SERVER = 'amer.epiqcorp.com'
LDAP_DOMAIN = 'EPIQCORP'

def authenticate(username, password):
    if not username or not password:
        return False

    try:
        user_dn = f"{LDAP_DOMAIN}\\{username}"
        server = Server(LDAP_SERVER, get_info=ALL)
        conn = Connection(server, user=user_dn, password=password, authentication=NTLM)
        return conn.bind()
    except Exception as e:
        print("LDAP auth error:", e)
        return False
