# TACACS+ Admin Web UI

## 🚀 Deployment Instructions

1. **Install dependencies** (Python 3.8+)
   ```bash
   pip install flask
   ```

2. **Install system requirements**
   ```bash
   sudo apt install tacacs+ freeradius
   ```

3. **Run the Flask App**
   ```bash
   sudo python3 app.py
   ```

4. **(Optional) Set up sudo permissions**

   In `/etc/sudoers`:
   ```
   www-data ALL=(ALL) NOPASSWD: /bin/systemctl restart tac_plus
   ```

5. **App Structure**
   - `app.py`: Flask backend
   - `templates/`: UI Pages (Tailwind + CodeMirror)
   - `utils/`: Config parsing logic
   - `tests/`: Pytest unit tests
   - `backups/`: Auto-generated backups of `tac_plus.conf`

6. **Test the App**
   ```bash
   pytest tests/
   ```

---

## 🔐 Notes

- Config file: `/etc/tacacs/tac_plus.conf`
- RADIUS file: `/etc/freeradius/3.0/mods-config/files/authorize`
- Uses `systemctl` to restart `tac_plus` after saving
- Backups are stored automatically
