from flask import Flask, render_template, request, redirect, flash, send_from_directory
import os
import shutil
import subprocess
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'supersecret'

# Config paths
TACACS_CONF_PATH = '/etc/tacacs/tacacs.conf'
RADIUS_CLIENTS_PATH = '/etc/freeradius/3.0/clients.conf'
BACKUP_DIR = '/etc/auth_backups'
DOCKER_CONTAINER_NAME = 'tacacs_plus'

# Ensure backup directory exists
os.makedirs(BACKUP_DIR, exist_ok=True)

def read_file(path):
    try:
        with open(path, 'r') as f:
            return f.read()
    except Exception as e:
        return f"Error reading {path}: {str(e)}"

def write_file(path, content):
    try:
        with open(path, 'w') as f:
            f.write(content)
        return True, "Saved successfully"
    except Exception as e:
        return False, f"Error writing to {path}: {str(e)}"

def backup_configs():
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_name = f'backup_{timestamp}'
    backup_path = os.path.join(BACKUP_DIR, backup_name)
    os.makedirs(backup_path, exist_ok=True)
    try:
        shutil.copy(TACACS_CONF_PATH, os.path.join(backup_path, 'tacacs.conf'))
        shutil.copy(RADIUS_CLIENTS_PATH, os.path.join(backup_path, 'clients.conf'))
        return True, f'Backup {backup_name} created'
    except Exception as e:
        return False, f'Backup failed: {str(e)}'

def restart_tacacs_container():
    try:
        subprocess.check_output(['docker', 'restart', DOCKER_CONTAINER_NAME])
        return True, f"Container '{DOCKER_CONTAINER_NAME}' restarted"
    except subprocess.CalledProcessError as e:
        return False, f"Failed to restart container: {e.output.decode()}"
    except FileNotFoundError:
        return False, "Docker not found or not installed"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/tacacs', methods=['GET', 'POST'])
def configure_tacacs():
    if request.method == 'POST':
        new_config = request.form['tacacs_config']
        success, msg = write_file(TACACS_CONF_PATH, new_config)
        flash(msg, 'success' if success else 'error')
        return redirect('/tacacs')
    config = read_file(TACACS_CONF_PATH)
    return render_template('editor.html', config=config, title='TACACS+ Config')

@app.route('/freeradius', methods=['GET', 'POST'])
def configure_radius():
    if request.method == 'POST':
        new_config = request.form['radius_config']
        success, msg = write_file(RADIUS_CLIENTS_PATH, new_config)
        flash(msg, 'success' if success else 'error')
        return redirect('/freeradius')
    config = read_file(RADIUS_CLIENTS_PATH)
    return render_template('editor.html', config=config, title='FreeRADIUS Clients Config', field_name='radius_config')

@app.route('/backup')
def create_backup():
    success, msg = backup_configs()
    flash(msg, 'success' if success else 'error')
    return redirect('/')

@app.route('/backups')
def list_backups():
    try:
        backups = os.listdir(BACKUP_DIR)
        backups.sort(reverse=True)
        return render_template('backups.html', backups=backups)
    except Exception as e:
        flash(f'Error listing backups: {str(e)}', 'error')
        return redirect('/')

@app.route('/download_backup/<backup>/<filename>')
def download_backup(backup, filename):
    path = os.path.join(BACKUP_DIR, backup)
    return send_from_directory(path, filename, as_attachment=True)

@app.route('/restart_tacacs')
def restart_tacacs():
    success, msg = restart_tacacs_container()
    flash(msg, 'success' if success else 'error')
    return redirect('/')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

@app.route('/tacacs_users', methods=['GET', 'POST'])
def tacacs_users():
    users = []

    if request.method == 'POST':
        # Get submitted users and regenerate config
        user_entries = request.form.getlist('username')
        user_secrets = request.form.getlist('password')
        new_config = "\n".join([
            f"user = {u} {{\n  default service = permit\n  login = cleartext {p}\n}}"
            for u, p in zip(user_entries, user_secrets) if u and p
        ])
        success, msg = write_file(TACACS_CONF_PATH, new_config)
        flash(msg, 'success' if success else 'error')
        return redirect('/tacacs_users')
    else:
        try:
            with open(TACACS_CONF_PATH) as f:
                lines = f.readlines()
            current_user = None
            for line in lines:
                line = line.strip()
                if line.startswith("user ="):
                    current_user = {'name': line.split()[2], 'password': ''}
                elif line.startswith("login = cleartext") and current_user:
                    current_user['password'] = line.split()[2]
                    users.append(current_user)
                    current_user = None
        except Exception:
            pass

    return render_template('users.html', users=users)
